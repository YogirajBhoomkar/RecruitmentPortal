import sys
import hashlib
import Services.LoginUsingEmailPassword as Read
import Interviewer.InterviewerDashboard as InterviewerDashboard
import Applicant.ApplicantDashboard as ApplicantDashboard

def Login():
    userType = input("Select User Type\n1. Applicant\n2. Interviewer : ")
    email=input("Enter email address: ")
    password=hashlib.md5(input("Enter password: ").encode('utf-8')).hexdigest()
    response=Read.get(userType,email,password)
    if(response == None):
        sys.stderr.write("Login failed.Please Check Details")
    else:
        if(userType == "1"):
            ApplicantDashboard.dashboard()
        elif(userType == "2"):
            InterviewerDashboard.dashboard()





