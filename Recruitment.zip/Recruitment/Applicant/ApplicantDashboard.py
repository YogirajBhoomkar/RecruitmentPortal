import sys

import Services.checkOTP as checkOTP
import Services.startTest as startTest
import Services.RecordScore as RecordScore
def dashboard():
    action=input("Select Action\n1.Give Test\nSelect: ")
    if action == "1":
        OTP=input("Enter OTP E-mailed to you: ")
        response=checkOTP.checkOTP(OTP)
        if(response!=None):
            score=startTest.startTest()
            recordResponse=RecordScore.RecordScore(OTP,score)
            if(recordResponse != None):
                print("Test Submitted Successfully. You will be communicated with further details via email")
        else:
            sys.stderr.write("Sorry but you couldn't clear the minimum qualification requirements. All the best for "
                             "you Future Endeavours!")



