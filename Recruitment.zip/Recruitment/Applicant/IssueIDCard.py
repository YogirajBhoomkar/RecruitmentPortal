import hashlib
print(hashlib.md5("whatever your string is whatever your string is".encode('utf-8')).hexdigest())
str="0e234e8c437bbdc92d5e236d3c39d038"
print(str.__len__())