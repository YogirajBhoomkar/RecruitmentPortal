import hashlib
import Services.Insert as ApplicantService
def RegisterationProces():

    ApplicantModel =[{
        "firstname": "",
        "lastname": "",
        "email": "",
        "password": "",
        "mobile": "",
        "resumeLink": "",
    }]

    print("Please Enter Your Personal Details here")
    firstname=input("First Name: ")
    lastname = input("Last Name: ")
    email=input("Email Address: ")
    password=hashlib.md5(input("Enter Password: ").encode('utf-8')).hexdigest()
    repeatPassowrd=hashlib.md5(input("Repeat Password: ").encode('utf-8')).hexdigest()

    while(password !=repeatPassowrd):
        print("Password don't match! Please match the passwords")
        password = hashlib.md5(input("Enter Password: ").encode('utf-8')).hexdigest()
        repeatPassowrd = hashlib.md5(input("Repeat Password: ").encode('utf-8')).hexdigest()
    mobile = input("Contact Number:")
    resumeLink=input("Enter your resume file Name: ")

    ApplicantModel[0]["firstname"] = firstname
    ApplicantModel[0]["lastname"] = lastname
    ApplicantModel[0]["email"] = email
    ApplicantModel[0]["password"] = password
    ApplicantModel[0]["mobile"] = mobile
    ApplicantModel[0]["resumeLink"] = resumeLink
    response=ApplicantService.Insert("applicant",ApplicantModel)
    if(response==True):
       return True
    else:
        return False

def IDCardIssue():
    return True;