import Signup
import mysqlconnector
import Login
mysqlconnector.connect()
print("1. Login\n2. Sign-up\n3. Exit")
action=""
action=input("Select: ")
while action!="3":
    if(action == "1"):
        Login.Login()
    elif(action =="2"):
        Signup.Signup()
    else:
        exit(0)
