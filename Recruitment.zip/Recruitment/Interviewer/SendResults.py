import mysql.connector
import smtplib
mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  password="root",
  database="recruitment"
)
server = smtplib.SMTP("smtp.gmail.com",587)
server.starttls()
server.login("pythonemailpython@gmail.com","pythonemail1.")



def send():
    mycursor = mydb.cursor()
    sql= "Select * from interviewlog"
    mycursor.execute(sql)
    response = mycursor.fetchall()
    for each in response:
        firstname=each[1]
        lastname=each[2]
        email=each[3]
        subject = "Congratulations! Welcome to Xoriant!"
        body = str("Dear "+str(firstname)+" "+str(lastname)+" Congratulations on clearing the hiring process and succesffult being a part of Xoriant! Further Details will be communicated via email soon. Thank you")
        body=body.replace(u"\U0001f603","")
        message="Subject:{}\n\n{}".format(subject,body)
        server.sendmail("pythonemailpython",email,message)

    server.quit()
    return True


    return response