import hashlib
import Services.Insert as InterviewerInsert

def RegisterationProcess():
    InterviewerModel = [{
        "firstname": "",
        "lastname": "",
        "email": "",
        "password": "",
        "mobile": "",
        "department": "",
    }]

    print("Please Enter Your Personal Details here")
    firstname = input("First Name: ")
    lastname = input("Last Name: ")
    email = input("Email Address: ")
    password = hashlib.md5(input("Enter Password: ").encode('utf-8')).hexdigest()
    repeatPassowrd = hashlib.md5(input("Repeat Password: ").encode('utf-8')).hexdigest()

    while (password != repeatPassowrd):
        print("Password don't match! Please match the passwords")
        password = hashlib.md5(input("Enter Password: ").encode('utf-8')).hexdigest()
        repeatPassowrd = hashlib.md5(input("Repeat Password: ").encode('utf-8')).hexdigest()
    mobile = input("Contact Number:")
    department = input("Enter your department: ")

    InterviewerModel[0]["firstname"] = firstname
    InterviewerModel[0]["lastname"] = lastname
    InterviewerModel[0]["email"] = email
    InterviewerModel[0]["password"] = password
    InterviewerModel[0]["mobile"] = mobile
    InterviewerModel[0]["department"] = department
    response = InterviewerInsert.Insert("interviewer", InterviewerModel)
    return response