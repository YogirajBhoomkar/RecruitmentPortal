import webbrowser
import mysql.connector
import Services.updateinterviewlog as UpdateInterviewLog
basePath=r'C:\Users\Yogiraj Bhoomkar\PycharmProjects\Recruitment\ApplicantResumes\"'
mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  password="root",
  database="recruitment"
)

mycursor = mydb.cursor()

def join():
    sql = "SELECT * from interviewlog ORDER BY interviewtime ASC"
    mycursor.execute(sql)
    response = mycursor.fetchall()
    for each in response:
        print("\n\n\t\tCandidate Details")
        print("\n\nID: "+str(each[0])+"\t\tInterview Scheduled at"+str(each[6]))
        print("\n Name: "+str(each[1])+" "+str(each[2]))
        print("\n Email: "+str(each[3]))
        print("\n Mobile: " + str(each[4]))
        print("\n ResumeLink: " + str(each[5]))
        action=input("\n\nJoin Room ? 1.Yes\n2. No: ")
        if action == "1":
            webbrowser.open(url=str(each[7]),new=2)
            webbrowser.open(url=basePath.replace('"', "")+str(each[5]),new=2)
            selection=input("Select Candidate? 1.Yes\n2.No: ")
            if selection == "1":
                UpdateInterviewLog.Update(str(each[0]))
        else:
            continue;