import Interviewer.SelectCandidates as InterviewerSelectCandidates
import Services.Notifications.TestNotification as TestNotification
import Services.Notifications.InterviewNotification as InterviewNotification
import Interviewer.JoinMeetingRoom as JoinMeetingRoom
import Interviewer.SendResults as SendResults
def dashboard():
    action="0"
    while action !="6":
        action = input(
            "1. Select Candidates\n2. Send Emails\n3. Send Interview Emails\n4. Enter Interview Room\n5. Broadcast Results\n6. Exit  ")
        if (action == "1"):
            InterviewerSelectCandidates.selectCandidates()
        elif (action == "2"):
            TestNotification.send()
        elif (action == "3"):
            InterviewNotification.sendInterviewDetails()
        elif (action == "4"):
            JoinMeetingRoom.join()
        elif(action == "5"):
            SendResults.send()
        else:
            return










