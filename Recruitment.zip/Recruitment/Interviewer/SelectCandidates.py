import webbrowser
import Services.GetAll as GetAll
import Services.SelectCandidate as Select
import Services.Notifications.TestNotification as SendEmails
basePath=r'C:\Users\Yogiraj Bhoomkar\PycharmProjects\Recruitment\ApplicantResumes\"'
def selectCandidates():
    response=GetAll.get("applicant")
    for each in response:
        id=each[0]
        print("ID: "+str(id)+"\nFirstName: "+each[1]+"\nLastName: "+each[2])
        resumeLink=basePath.replace('"',"")+each[6]
        webbrowser.open(url=resumeLink,new=1)
        action=input("Select the Candidate For Test?\n1.Yes\n2.No\nType 1 or 2: ")
        if(action == "1"):
            time=input("Please enter the time for test in (HH:MM) Format: ")
            Select.SelectCandidates(id,time)
            SendEmails.send()

        elif(action =="2"):
            continue
        else:
            print("Invalid Input")
