import random

import mysql.connector
import Services.GetAllWhereId as GetAllWhere
mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  password="root",
  database="recruitment"
)

mycursor = mydb.cursor()
def SelectCandidates(id,time):
    Applicants=GetAllWhere.getAllWhereId("applicant",id)
    sql = "INSERT INTO testselectedcandidates (id,firstname,lastname,email,mobile) VALUES (%s, %s, %s, %s, %s)"
    val = (Applicants[0], Applicants[1], Applicants[2], Applicants[3], Applicants[5],)
    mycursor.execute(sql,val)
    mydb.commit()
    OTP= random.randint(1000,9999)
    sql1 = "INSERT INTO testcandidatesotp (id,firstname,lastname,email,mobile,otp,time) VALUES (%s, %s, %s, %s, %s, %s, %s)"
    val1 = (Applicants[0], Applicants[1], Applicants[2], Applicants[3], Applicants[5], "" + str(OTP), time,)
    response = mycursor.execute(sql1, val1)
    mydb.commit()
    return response
