import mysql.connector

mydb = mysql.connector.connect(
    host="localhost",
    user="root",
    password="root",
    database="recruitment"
)

mycursor = mydb.cursor()


def getAllWhereId(userType, parameterValue):
    id=""+str(parameterValue)
    if userType == "applicant":
        sql = "SELECT * from applicantdetails where id = (%s)"
        val = id
    elif userType == "interviewer":
        sql = "SELECT * from interviewerdetails where id = %s"
        val = id
    else:
        return False
    mycursor.execute(sql,(val,))
    response = mycursor.fetchone()
    return response
