import mysql.connector
import smtplib
mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  password="root",
  database="recruitment"
)
server = smtplib.SMTP("smtp.gmail.com",587)
server.starttls()
server.login("pythonemailpython@gmail.com","pythonemail1.")



def send():
    mycursor = mydb.cursor()
    sql= "Select * from testcandidatesotp"
    mycursor.execute(sql)
    response = mycursor.fetchall()
    for each in response:
        firstname=each[1]
        lastname=each[2]
        email=each[3]
        otp=each[5]
        time=each[6]
        subject = "Xoriant Test Scheduled Today"
        body = str("Dear "+str(firstname)+" "+str(lastname)+" Your First round for Xoriant is scheduled today at "+str(time)+". Your OTP for the Test is: "+str(otp)+". All the best! :-)")
        body=body.replace(u"\U0001f603","")
        message="Subject:{}\n\n{}".format(subject,body)
        server.sendmail("pythonemailpython",email,message)

    server.quit()
    return True


    return response