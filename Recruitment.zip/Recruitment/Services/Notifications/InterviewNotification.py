import mysql.connector
import smtplib
mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  password="root",
  database="recruitment"
)
server = smtplib.SMTP("smtp.gmail.com",587)
server.starttls()
server.login("pythonemailpython@gmail.com","pythonemail1.")



def sendInterviewDetails():
    mycursor = mydb.cursor()
    sql= "Select OTP from selectedforinterview"
    mycursor.execute(sql)
    response = mycursor.fetchall()
    print("Response:")
    print(response)
    for each in response:
        otp=each[0]
        sql1="Select * from testcandidatesotp  where OTP = (%s)"
        val1=(otp)
        mycursor.execute(sql1,(val1,))
        details=mycursor.fetchone()
        mydb.commit()
        id=details[0]
        firstname = details[1]
        lastname = details[2]
        email = details[3]
        mobile=details[4]
        interviewtime=input("Interview Time: ")
        time = interviewtime
        meetingLink="https://meet.google.com/ykz-dzra-snr"
        subject = "Xoriant Interview Scheduled Today"
        body = str("Congratulations, "+str(firstname)+" "+str(lastname)+" Your First round for Xoriant is sucessfully cleared. We have scheduled your Interview round at "+str(time)+", Today. Your link for the meeting is "+str(meetingLink)+". Please Join on time.  All the best! :-)")
        body=body.replace(u"\U0001f603","")
        message="Subject:{}\n\n{}".format(subject,body)
        server.sendmail("pythonemailpython",email,message)
        sql1 = "Select * from applicantdetails  where id = (%s)"
        val1 = (id)
        mycursor.execute(sql1, (val1,))
        resumeLink = mycursor.fetchone()
        resumeLink=resumeLink[6]
        sqlQuery="INSERT into interviewlog (id,firstname,lastname,email,mobile,resumeLink,interviewtime,meetinglink,selectedstatus) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)"
        selected = "false"
        data=(id,firstname,lastname,email,mobile,resumeLink,time,meetingLink,selected)
        mycursor.execute(sqlQuery,data)
        mydb.commit()
    server.quit()



    return response