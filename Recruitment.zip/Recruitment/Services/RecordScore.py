import mysql.connector

mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  password="root",
  database="recruitment"
)

mycursor = mydb.cursor()
def RecordScore(otp,score):
    sql = "INSERT INTO selectedforinterview (otp,score) VALUES (%s, %s)"
    val = (otp,score)
    response=mycursor.execute(sql, val)
    mydb.commit()
    print(response)
    return response
