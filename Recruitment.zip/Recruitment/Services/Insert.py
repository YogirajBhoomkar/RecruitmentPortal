import mysql.connector

mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  password="root",
  database="recruitment"
)

mycursor = mydb.cursor()
def Insert(userType,details):
    if(userType=="applicant"):
        Applicant=details
        sql = "INSERT INTO applicantdetails (firstname,lastname,email,password,mobile,resumeLink) VALUES (%s, %s, %s, %s, %s, %s)"
        val = (Applicant[0]["firstname"],Applicant[0]["lastname"],Applicant[0]["email"],Applicant[0]["password"],Applicant[0]["mobile"],Applicant[0]["resumeLink"])
    elif(userType=="interviewer"):
        Interviewer=details
        sql = "INSERT INTO interviewerdetails (firstname,lastname,email,password,mobile,department) VALUES (%s, %s, %s, %s, %s, %s)"
        val = (Interviewer[0]["firstname"], Interviewer[0]["lastname"], Interviewer[0]["email"], Interviewer[0]["password"], Interviewer[0]["mobile"],Interviewer[0]["department"])
    else:
        print("from Insert Service Admin Work Remaining")

    response=mycursor.execute(sql, val)
    mydb.commit()
    return response
