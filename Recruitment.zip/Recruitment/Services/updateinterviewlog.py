import mysql.connector

mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  password="root",
  database="recruitment"
)

mycursor = mydb.cursor()
def Update(id):
    sql = "update interviewlog set selectedstatus = %s where id= %s"
    val=("true",id)
    response=mycursor.execute(sql, val)
    mydb.commit()
    return response
