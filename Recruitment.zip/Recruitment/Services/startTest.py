import random
from time import sleep

import mysql.connector

mydb = mysql.connector.connect(
    host="localhost",
    user="root",
    password="root",
    database="recruitment"
)

def startTest():
    questionNumbers=[]
    Data=[]
    answers=[]
    QuestionData={
        "id":"",
        "question":"",
        "option1":"",
        "option2":"",
        "option3":"",
        "option4":"",
        "correctanswer":""
    }
    counter=0
    while counter<3:
        randomNumber=random.randint(1,6)
        if counter==0:
            questionNumbers.append(randomNumber)
            counter+=1
        else:
            for each in questionNumbers:
                if each == randomNumber:
                    randomNumber=random.randint(1,6)
            questionNumbers.append(randomNumber)
            counter+=1
    mycursor = mydb.cursor()
    for each in questionNumbers:
        sql = "SELECT * from questionbank where id = (%s)"
        val = each
        mycursor.execute(sql, (val,))
        response = mycursor.fetchone()
        QuestionData["id"]=response[0]
        QuestionData["question"]=response[1]
        QuestionData["option1"]=response[2]
        QuestionData["option2"] = response[3]
        QuestionData["option3"] = response[4]
        QuestionData["option4"] = response[5]
        QuestionData["correctanswer"] = response[6]
        Data.append(QuestionData)
        QuestionData = {
            "id": "",
            "question": "",
            "option1": "",
            "option2": "",
            "option3": "",
            "option4": "",
            "correctanswer": ""
        }
    print("\n\n\t\t\t\t\t\tReact JS\n")

    print("Test Starting in 3")
    sleep(1)
    print("Test Starting in 2")
    sleep(1)
    print("Test Starting in 1")
    sleep(1)
    print("\n\n\n")
    for _,each in enumerate(Data):
        print("+-----------------------------------------------------------+")
        print(each["question"])
        print("+-----------------------------------------------------------+")
        print(each["option1"])
        print(each["option2"])
        print(each["option3"])
        print(each["option4"])
        print("+-----------------------------------------------------------+")
        answers.append(input("Your answer: "))
        print("+-----------------------------------------------------------+\n\n")
    score=0
    threshold=20
    for index,each in enumerate(Data):
        if each["correctanswer"] == answers[index]:
            score+=1
    return score*10