import mysql.connector

mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  password="root",
  database="recruitment"
)

mycursor = mydb.cursor()

def checkOTP(OTP):
    sql = "SELECT id from testcandidatesotp where OTP = (%s)"
    val = (OTP)
    mycursor.execute(sql,(val,))
    response = mycursor.fetchone()
    return response