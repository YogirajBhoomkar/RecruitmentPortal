import mysql.connector

mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  password="root",
  database="recruitment"
)

mycursor = mydb.cursor()

def get(userType,email,password):

  if(userType == "applicant"):
    sql = "SELECT id from applicantdetails where email = %s AND password = %s"
    val = (email,password)
  elif(userType == "interviewer"):
    sql = "SELECT id from interviewerdetails where email = %s AND password = %s"
    val = (email, password)
  else:
    return False

  mycursor.execute(sql,val)
  response = mycursor.fetchone()
  return response