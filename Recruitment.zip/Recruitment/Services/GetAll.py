import mysql.connector

mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  password="root",
  database="recruitment"
)

mycursor = mydb.cursor()

def get(userType):
  if(userType == "applicant"):
    sql = "SELECT * from applicantdetails;"
  elif(userType == "interviewer"):
    sql = "SELECT * from interviewerdetails;"
  else:
    return False

  mycursor.execute(sql)
  response = mycursor.fetchall()
  return response