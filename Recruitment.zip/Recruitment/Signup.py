import Applicant.Register as ApplicantRegister
import Interviewer.Register as RegisterInterviewer
import Interviewer.InterviewerDashboard as InterviewerDashboard
import Applicant.ApplicantDashboard as ApplicantDashboard
import sys


def Signup():
    usertype = input("Select User Type\n1. Applicant\n2. Interviewer\n")
    if (usertype == "1"):
        response = ApplicantRegister.RegisterationProces()
        if (response != None):
            print("Applicant Successfully Registered for the Recruitment Drive")
            ApplicantDashboard.dashboard()
        else:
            sys.stderr.write("Registration failed. Please Try again next time. All the Best!")

    elif (usertype == "2"):
        response = RegisterInterviewer.RegisterationProcess()
        if (response):
            print("Interviewer Successfully Registered for the Upcoming Recruitment Drive")
            InterviewerDashboard.dashboard()
        else:
            sys.stderr.write("Registration failed.Please Contact Sysnet Team.")


    else:
        sys.stderr.write("Invalid User Type")
